﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NubeSpawner : MonoBehaviour {
    public GameObject nubes;
    float randX;
    Vector2 whereToSpawn;
    public float spawnRate = 10f; //Por defecto las nubes aparecen cada 10 segundos
    float nextSpawn = 0.0f;
	
	// Update is called once per frame
	void Update () {
		if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnRate;
            whereToSpawn = new Vector2(50, 6);
            Instantiate(nubes, whereToSpawn, Quaternion.identity);
        }
	}
}
