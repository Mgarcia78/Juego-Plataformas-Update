﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GamePlay : MonoBehaviour {
    public MotoControl motorista;
    public Text recordText;
    public Button startButton;
    public Button siguenteNivelButton;
    public GameObject audioLevel;
    public GameObject trampa;

    private int segundosParaEmpezar = 3;
    private Text mainText;
    private float tiempoInicial;
    private float tiempoRecord;
    private int nivel;
    private bool reinicio;
    private float temporizador = 1.656f;
    private bool activaSonido = false;
    private bool win = false;

    void Start () {
        motorista.eliminado += Reiniciar;
        motorista.finalNivel += Final;
        motorista.enabled = false;
        mainText = startButton.GetComponentInChildren<Text>();
        tiempoRecord = PlayerPrefs.GetFloat("tiempo record", 0);

        //Hay que inicializar la variable nivel con el valor nivel guardado para que funcione correctamente
        nivel = PlayerPrefs.GetInt("nivel", 0);

        if (tiempoRecord > 0) recordText.text = "Record: " + tiempoRecord.ToString("##.##");

        recordText.enabled = false;
        siguenteNivelButton.gameObject.SetActive(false);
        audioLevel.gameObject.SetActive(false);
        trampa.gameObject.SetActive(false);

        motorista.trampaActiva += ActivaTrampa;
    }

    private void ActivaTrampa()
    {
        trampa.gameObject.SetActive(true);
    }

    public void Reiniciar()
    {
        if(activaSonido == false)
        {
            activaSonido = true;
            motorista.GetComponent<AudioSource>().Play(0);
        }
        reinicio = true;
    }

    private void TemporizadorReinicio()
    {
        if (reinicio == true)
        {
            temporizador -= Time.deltaTime;
            if (temporizador < 0)
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
        }
    }
    public void StartGame()
    {
        startButton.enabled = false;
        mainText.text = "" + segundosParaEmpezar;
        InvokeRepeating("CuentaAtras", 1, 1);
    }

    void CuentaAtras()
    {
        segundosParaEmpezar--;

        if (segundosParaEmpezar <= 0)
        {
            CancelInvoke();
            JuegoEmpezado();
        }
        else mainText.text = "" + segundosParaEmpezar;
    }

    void JuegoEmpezado()
    {
        audioLevel.gameObject.SetActive(true);
        motorista.enabled = true;
        tiempoInicial = Time.time;
        if (tiempoRecord > 0) recordText.enabled = true;
    }

    void Update()
    {
        if (motorista.enabled)
        {
            mainText.text = "Time: " + (Time.time - tiempoInicial).ToString("##.##");
        }

        TemporizadorReinicio();
    }

    void Final()
    {
        motorista.enabled = false;
        mainText.text = "Final! " + (Time.time - tiempoInicial);
        PlayerPrefs.SetFloat("tiempo record", (Time.time - tiempoInicial));

        siguenteNivelButton.gameObject.SetActive(true);
    }

    public void NextLevel()
    {
        nivel++;
        PlayerPrefs.SetInt("nivel", nivel); 
 
        switch (nivel)
      {
          case 1:
              SceneManager.LoadScene("Nivel2");
              break;
          case 2:
              SceneManager.LoadScene("Nivel3");
              break; 
          case 3:
              SceneManager.LoadScene("PantallaFelicitaciones");
              break;
          default:
              break;
      }
    }
}
