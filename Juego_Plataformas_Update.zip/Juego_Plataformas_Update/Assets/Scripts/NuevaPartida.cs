﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class NuevaPartida : MonoBehaviour {
    private int nivel = 0;

    public void CargarPartidaNueva()
    {
        PlayerPrefs.SetInt("nivel", nivel);

        SceneManager.LoadScene("Nivel1");
    }
}
