﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuInicial : MonoBehaviour {
    public void CargarMenuInicial()
    {
        SceneManager.LoadScene("PantallaInicial");
    }
}
