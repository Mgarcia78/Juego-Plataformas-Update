﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuCreditos : MonoBehaviour {
    public void CargarCreditos()
    {
        SceneManager.LoadScene("PantallaCreditos");
    }
}
